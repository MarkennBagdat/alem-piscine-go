package piscine

func TrimAtoi(s string) int {
	sign := 1
	result := 0

	for _, char := range s {
		if char >= '0' && char <= '9' {
			result = result*10 + int(char-'0')
		} else if char == '-' && result == 0 {
			sign = -1
		}
	}
	return result * sign
}
