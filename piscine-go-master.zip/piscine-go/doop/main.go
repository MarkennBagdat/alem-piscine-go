package main

import (
	"os"

	"github.com/01-edu/z01"
)

func main() {
	args := os.Args
	res := 0
	str := "No division by 0"
	str1 := "No modulo by 0"
	if len(args) != 4 {
		return
	}
	if args[1][0] == '-' || args[3][0] == '-' {
		for i := 1; i < len(args[1]); i++ {
			if !(args[1][i] >= '0' && args[1][i] <= '9') {
				return
			}
		}
		for i := 1; i < len(args[3]); i++ {
			if !(args[3][i] >= '0' && args[3][i] <= '9') {
				return
			}
		}
	} else {
		for i := 0; i < len(args[1]); i++ {
			if !(args[1][i] >= '0' && args[1][i] <= '9') {
				return
			}
		}
		for i := 0; i < len(args[3]); i++ {
			if !(args[3][i] >= '0' && args[3][i] <= '9') {
				return
			}
		}
	}
	if !(args[2] == "/" || args[2] == "*" || args[2] == "+" || args[2] == "%" || args[2] == "-") {
		return
	}
	args1 := Atoi(args[1])
	args2 := Atoi(args[3])
	if args1 > 2147483647 || args1 < -2147483647 || args2 > 2147483647 || args2 < -2147483647 {
		return
	}
	args11 := int(args1)
	args22 := int(args2)
	switch args[2] {
	case "*":
		res = args11 * args22
	case "+":
		res = args11 + args22
	case "-":
		res = args11 - args22
	case "/":
		if args[3] == "0" {
			for i := 0; i < len(str); i++ {
				z01.PrintRune(rune(str[i]))
			}
			z01.PrintRune('\n')
			return
		}
		res = args11 / args22
	case "%":
		if args[3] == "0" {
			for i := 0; i < len(str1); i++ {
				z01.PrintRune(rune(str1[i]))
			}
			z01.PrintRune('\n')
			return
		}
		res = args11 % args22
	}
	PrintNbr(res)
	z01.PrintRune('\n')
}

func Atoi(s string) int64 {
	var num int64
	var sign int64 = 1
	idx := 0
	if s[0] == '-' {
		sign = -1
		idx++
	}
	for idx < len(s) {
		digit := int64(s[idx] - '0')
		num = num*10 + digit
		idx++
	}
	return num * sign
}

func PrintNbr(n int) {
	if n >= 0 {
		if n/10 == 0 {
			z01.PrintRune(rune('0' + n))
		} else {
			new_n := n % 10
			PrintNbr(n / 10)
			z01.PrintRune(rune('0' + new_n))
		}
	} else if n < 0 {
		n *= -1
		z01.PrintRune('-')
		if n/10 == 0 {
			z01.PrintRune(rune('0' + n))
		} else {
			new_n := n % 10
			PrintNbr(n / 10)
			z01.PrintRune(rune('0' + new_n))
		}
	}
}
