package main

import (
	"github.com/01-edu/z01"
)

type point struct {
	x int
	y int
}

func PrintStr(str string) {
	arrayStr := []rune(str)

	for i := range arrayStr {
		z01.PrintRune(arrayStr[i])
	}
}

func setPoint(ptr *point) {
	ptr.x = 42
	ptr.y = 21
}

func PrintInt(r int) {
	count := '0'

	if r/10 > 0 {
		PrintInt(r / 10)
	}

	for i := 0; i < r%10; i++ {
		count++
	}
	z01.PrintRune(count)
}

func main() {
	points := &point{}

	setPoint(points)

	PrintStr("x = ")
	PrintInt(points.x)
	PrintStr(", y = ")
	PrintInt(points.y)
	z01.PrintRune('\n')
}
