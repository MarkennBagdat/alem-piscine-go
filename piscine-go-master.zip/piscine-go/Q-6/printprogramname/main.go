package main

import (
	"os"
)

func main() {
	args := os.Args
	progName := args[0]
	for i := len(progName) - 1; i >= 0; i-- {
		if progName[i] == '/' {
			progName = progName[i+1:]
			break
		}
	}
	os.Stdout.WriteString(progName + "\n")
}
