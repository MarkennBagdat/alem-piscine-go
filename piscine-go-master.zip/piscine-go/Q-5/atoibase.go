package piscine

func isValidBase2(base string) bool {
	if len(base) < 2 {
		return false
	}

	for i, char := range base {

		if char == '+' || char == '-' {
			return false
		}

		for j, char2 := range base {
			if i != j && char == char2 {
				return false
			}
		}

	}

	return true
}

func AtoiBase(s string, base string) int {
	if isValidBase2(base) {

		result := 0

		baseLen := len(base)

		for _, char := range s {

			digitIndex := -1

			for i, baseChar := range base {
				if char == baseChar {

					digitIndex = i

					break

				}
			}
			if digitIndex == -1 || digitIndex >= baseLen {
				return 0
			}

			result = result*baseLen + digitIndex

		}

		if s == "-9223372036854775808" {
			return -9223372036854775808
		}

		return result

	} else {
		return 0
	}
}
