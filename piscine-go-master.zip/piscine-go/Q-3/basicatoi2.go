package piscine

func BasicAtoi2(s string) int {
	result := 0

	for _, ch := range s {
		num := ch - '0'
		if num >= 0 && num <= 9 {
			result = result*10 + int(num)
		} else {
			return 0
		}
	}
	return result
}
