package piscine

func ListClear(l *List) {
	l.Head = nil
}
