package piscine

func SplitWhiteSpaces(s string) []string {
	var answer []string
	mainWord := ""
	for i, ch := range s {
		if ch == ' ' || ch == '\t' || ch == '\n' {
			if mainWord != "" {
				answer = append(answer, mainWord)
				mainWord = ""
			}
		} else {
			mainWord += string(s[i])
		}
	}
	if mainWord != "" {
		answer = append(answer, mainWord)
	}
	return answer
}
