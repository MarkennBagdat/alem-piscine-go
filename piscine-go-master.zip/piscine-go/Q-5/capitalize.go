package piscine

func Capitalize(s string) string {
	answer := []byte(s)
	shouldCapitalize := true

	for i, char := range s {
		if (char >= 'a' && char <= 'z') || (char >= 'A' && char <= 'Z') || (char >= '0' && char <= '9') {
			if shouldCapitalize && answer[i] >= 'a' && answer[i] <= 'z' {
				answer[i] -= 32
			} else if !shouldCapitalize && answer[i] >= 'A' && answer[i] <= 'Z' {
				answer[i] += 32
			}
			shouldCapitalize = false
		} else {
			shouldCapitalize = true
		}
	}
	return string(answer)
}
