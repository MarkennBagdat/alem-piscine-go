package piscine

func Atoi(s string) int {
	result := 0
	sing := 1

	for i, ch := range s {
		if ch == '-' && i == 0 {
			sing = -1
			continue
		}
		if ch == '+' && i == 0 {
			continue
		}

		num := ch - '0'
		if num < 0 || num > 9 {
			return 0
		}
		result = result*10 + int(num)
	}
	return result * sing
}
