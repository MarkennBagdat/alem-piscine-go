package piscine

func ConcatParams(args []string) string {
	answer := args[0]

	for i, char := range args {
		if i >= 1 {
			answer += "\n" + char
		}
	}
	return answer
}
