package piscine

func Split(s, sep string) []string {
	var answer []string
	begin := 0
	for i := 0; i <= len(s)-len(sep); i++ {
		if s[i:i+len(sep)] == sep {
			if i != begin {
				answer = append(answer, s[begin:i])
			}
			i += len(sep) - 1
			begin = i + 1
		}

		// if index == -1 {
		// 	answer = append(answer, s)
		// 	break
		// }
		// answer = append(answer, s[index:i])
		// s = s[index+len(sep):]
	}
	if begin < len(s) {
		answer = append(answer, s[begin:])
	}
	return answer
}
