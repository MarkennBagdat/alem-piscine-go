package main

import (
	"io/ioutil"
	"os"
)

func main() {
	args := os.Args[1:]

	if len(args) == 0 {
		char, err := ioutil.ReadAll(os.Stdin)
		if err != nil {
			fmt.Println("ERROR: ", err)
			return
		}
		os.Stdin.Write(char)
		return
	}

	for _, filename := range args {
		char, err := ioutil.ReadFile(filename)
		if err != nil {
			fmt.Println("ERROR: ", err)
			return
		}
		os.Stdin.Write(char)
	}
}
