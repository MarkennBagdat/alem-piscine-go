package main

import (
	"os"
)

func main() {
	args := os.Args[1:]
	printReverse(args)
}

func printReverse(args []string) {
	for i := len(args) - 1; i >= 0; i-- {
		printRunes(args[i])
	}
}

func printRunes(s string) {
	for _, r := range s {
		printRune(r)
	}
	printRune('\n')
}

func printRune(r rune) {
	os.Stdout.Write([]byte(string(r)))
}
