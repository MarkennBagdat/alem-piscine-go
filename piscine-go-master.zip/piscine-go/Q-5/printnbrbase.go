package piscine

import "github.com/01-edu/z01"

func toRuneInPrintBrBase(s string) {
	for _, char := range s {
		z01.PrintRune(char)
	}
}

func isValidBase(base string) bool {
	if len(base) < 2 {
		return false
	}

	for i, char := range base {

		if char == '+' || char == '-' {
			return false
		}

		for j, char2 := range base {
			if i != j && char == char2 {
				return false
			}
		}

	}

	return true
}

func PrintNbrBase(n int, base string) {
	if isValidBase(base) {

		isNegative := false

		if n < 0 {

			isNegative = true

			n = -n

		}

		result := ""

		baseLen := len(base)

		for n > 0 {

			remainder := n % baseLen

			result = string(base[remainder]) + result

			n /= baseLen

		}

		if isNegative {
			z01.PrintRune('-')
		}

		if n == -9223372036854775808 {
			toRuneInPrintBrBase("9223372036854775808")
		}

		toRuneInPrintBrBase(result)

	} else {
		toRuneInPrintBrBase("NV")
	}
}
