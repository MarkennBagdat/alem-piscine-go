package piscine

import (
	"github.com/01-edu/z01"
)

func PrintComb2() {
	for i := 0; i <= 98; i++ {
		first := i / 10
		second := i % 10
		for j := i + 1; j <= 99; j++ {
			third := j / 10
			fourth := j % 10
			z01.PrintRune(rune('0' + first))
			z01.PrintRune(rune('0' + second))
			z01.PrintRune(' ')
			z01.PrintRune(rune('0' + third))
			z01.PrintRune(rune('0' + fourth))

			if i < 98 {
				z01.PrintRune(',')
				z01.PrintRune(' ')
			}
		}
	}
	z01.PrintRune('\n')
}
