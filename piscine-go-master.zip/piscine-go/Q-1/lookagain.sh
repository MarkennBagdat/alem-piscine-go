find -type f -name '*.sh' | grep -oE '[^/]+\.sh$'| cut -d '.' -f 1
