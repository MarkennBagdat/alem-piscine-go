package piscine

import "github.com/01-edu/z01"

func PrintNbrInOrder(n int) {
	count := [10]int{}
	number := []rune{}

	if n == 0 {
		z01.PrintRune('0')
		return
	}

	for n > 0 {
		digit := n % 10
		count[digit]++
		n /= 10
	}

	for digit, value := range count {
		for value > 0 {
			number = append(number, rune(digit)+'0')
			value--
		}
	}

	for i := 0; i <= len(number)-1; i++ {
		z01.PrintRune(number[i])
	}
}
