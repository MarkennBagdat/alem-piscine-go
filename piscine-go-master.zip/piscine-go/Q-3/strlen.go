package piscine

func StrLen(s string) int {
	return len([]rune(s))
}
