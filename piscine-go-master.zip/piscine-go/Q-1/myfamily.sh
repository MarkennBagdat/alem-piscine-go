
  super_data=$(curl -s https://01.alem.school/assets/superhero/all.json | jq --argjson id "$HERO_ID" '.[] | select(.id == $id) | .connections.relatives')
  
  relatives=$(echo "$super_data" | tr -d '"')

  echo "$relatives"