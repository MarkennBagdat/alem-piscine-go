package main

import (
	"os"
)

func main() {
	args := os.Args[1:]

	for i := 0; i < len(args)-1; i++ {
		for j := 0; j < len(args)-1; j++ {
			if args[j] > args[j+1] {
				args[j], args[j+1] = args[j+1], args[j]
			}
		}
	}
	for _, char := range args {
		printRunes(char)
	}
}

func printRunes(s string) {
	for _, r := range s {
		printRune(r)
	}
	printRune('\n')
}

func printRune(r rune) {
	os.Stdout.Write([]byte(string(r)))
}
