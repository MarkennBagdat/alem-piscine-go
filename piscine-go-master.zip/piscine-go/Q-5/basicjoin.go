package piscine

func BasicJoin(elems []string) string {
	answer := ""
	for _, char := range elems {
		answer += char
	}
	return answer
}
