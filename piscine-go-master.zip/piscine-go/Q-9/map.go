package piscine

func Map(f func(int) bool, a []int) []bool {
	ans := make([]bool, len(a))
	for i, ch := range a {
		ans[i] = f(ch)
	}
	return ans
}
