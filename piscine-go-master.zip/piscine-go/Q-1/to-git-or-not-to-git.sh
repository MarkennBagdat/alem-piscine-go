get_superhero() {
  local url="https://01.alem.school/assets/superhero/all.json"
  
  local super_data=$(curl -s "$url" | jq --argjson id "$1" '.[] | select(.id == $id)')
  
  local name=$(printf '%s' "$super_data" | jq -r '.name')
  local power=$(printf '%s' "$super_data" | jq -r '.powerstats.power')
  local gender=$(printf '%s' "$super_data" | jq -r '.appearance.gender')

  printf '%s\n%s\n%s\n' $name $power $gender
}
get_superhero 170