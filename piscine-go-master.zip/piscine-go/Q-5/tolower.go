package piscine

func ToLower(s string) string {
	answer := ""
	for _, char := range s {
		if char >= 'A' && char <= 'Z' {
			answer += string(char + 32)
		} else {
			answer += string(char)
		}
	}
	return answer
}
