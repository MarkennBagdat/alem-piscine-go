package main

import (
	"os"
)

func main() {
	args := os.Args[1:]
	for _, char := range args {
		printRunes(char)
	}
}

func printRunes(s string) {
	for _, r := range s {
		printRune(r)
	}
	printRune('\n')
}

func printRune(r rune) {
	os.Stdout.Write([]byte(string(r)))
}
